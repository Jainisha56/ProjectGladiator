export class Bankdetails {
    Account_Num !:number
    user_ref_id !: number
    bank_name !:string
account_type !:string
branch_name !:string
ifsc_code !:string

}
