export class Employmentdetails {
    emp_id !:number

user_id !:number
type_of_emp !: string
annual_sal!:number
 existing_emi!:string
  Work_Experience !:number
}
